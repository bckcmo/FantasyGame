/*
*Program Name: Project 3
*Author: Brendan Corazzin
*Date: 5/05/2017
*Description: This is the implementation file for the menu function.
*/

#include <iostream>
#include "validateInput.hpp"
#include <string>

/*
*The menu function prints options to the console and prompts the user to select an int 
*value which corresponds to each option. The function returns the value selected.
*/

int menu()
{
	std::string strMenuOption = "invalid input";
	int menuOption;
	
	do
	{
		std::cout << std::endl;
		std::cout << std::endl;
		std::cout << "Select an option from the menu: " << std::endl;
		std::cout << "Enter 1 to enter Fantasy World." << std::endl;
		std::cout << "Enter 2 to exit the program." << std::endl;
		getline(std::cin, strMenuOption);
	}while(validateInput(strMenuOption, menuOption) != 0 || menuOption > 2 || menuOption < 1);
	
	return menuOption;
}

