/*
*Program Name: Project 3
*Author: Brendan Corazzin
*Date: 5/05/2017
*Description: This is the header file for the menu function.
*/

#ifndef MENU_HPP
#define MENU_HPP

int menu();

#endif